<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Assignment 1 - Courses</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <ul>
            <li><a id="myNameInNav">Glenn Eirik Hansen</a></li>
            <li><a href="students.php">Students</a></li>
            <li><a href="courses.php" id="active">Courses</a></li>
            <li><a href="data.php">Upload</a></li>
        </ul>
    </nav>
    <h1>Courses</h1>
</body>
</html>
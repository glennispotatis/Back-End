Assignment 1 - Back End Web Development

The file that needs to be uploaded is named "studentDatabase.csv". The "data.php" will sort the different data to the correct databases.

"studentDB.csv" is the database for all the students. "coursesDB.csv" is for courses. "coursesTakenDB.csv" is for courses 
taken by the students. As of right now, these are empty, to get started: 
    1. go to data.php
    2. upload the "studentDatabase.csv" file
    3. go to students.php
    4. A table and a counter will show the students
    5. To wipe the databases, delete everything except the first line (!THIS IS IMPORTANT! Otherwise it won't work)

ENJOY!

- Glenn Eirik Hansen